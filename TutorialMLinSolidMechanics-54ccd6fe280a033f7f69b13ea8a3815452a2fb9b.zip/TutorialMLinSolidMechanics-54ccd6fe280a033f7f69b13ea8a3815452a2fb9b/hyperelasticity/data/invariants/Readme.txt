Data format 
I_1 J I_4 I_5
