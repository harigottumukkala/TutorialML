# Task 2: Hyperelasticity

The relevant data for this task can be found in the `data` directory.

**Data schema**

F11 F12 F13 F21 F22 F23 F31 F32 F33   P11 P12 P13 P21 P22 P23 P31 P32 P33   W

**Deformation gradient F**

F=[F11 F12 F13
   F21 F22 F23
   F31 F32 F33]

**First Piola Stress P**

P=[P11 P12 P13
   P21 P22 P23
   P31 P32 P33]

**Strain energy density W**

W
